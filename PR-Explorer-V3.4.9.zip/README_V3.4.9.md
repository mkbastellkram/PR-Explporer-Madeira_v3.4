# PRX V3.4.9 · Bottom Navigation Geometry Fix

## Problem
Die Bottom-Nav hatte die Safe-Area-Inset-Bottom dreifach reserviert:
1. `#app` hatte `padding-bottom: env(safe-area-inset-bottom)`
2. `.modebar` hatte `height: calc(62px + env(safe-area-inset-bottom))`
3. `.modebar` hatte `padding-bottom: calc(6px + env(safe-area-inset-bottom))`
→ Ergebnis: ~2cm schwarzer Leerraum unter der Nav, Karte zu klein

## Lösung

### Neue CSS-Variablen (`:root`)
```css
--prx-nav-core: 62px;
--prx-nav-total: calc(var(--prx-nav-core) + env(safe-area-inset-bottom));
```

### Geänderte Regeln
| Element | Vorher | Nachher |
|---|---|---|
| `#app` | `position:relative` + `padding-bottom:env(...)` | `position:fixed;inset:0` — kein padding-bottom |
| `#map` | `inset:0` (volle Höhe) | `bottom:var(--prx-nav-total)` |
| `.modebar` | `height:calc(62px + env(...))` + `padding-bottom:calc(6px+env(...))` | `height:var(--prx-nav-total)` + `padding-bottom:env(...)` nur einmal |
| `.carousel-shell` | `bottom:calc(66px + env(...))` | `bottom:var(--prx-nav-total)` |
| `.settings-panel` etc. | `bottom:calc(72px + env(...))` | `bottom:var(--prx-nav-total)` |
| `.toast` | `bottom:calc(86px + env(...))` | `bottom:calc(var(--prx-nav-total) + 10px)` |
| `.detail-sheet` | `padding-bottom:calc(78px + env(...))` | `padding-bottom:calc(var(--prx-nav-total) + 12px)` |

### app.js
- `initMap()`: Triple `invalidateSize(true)` via `requestAnimationFrame` + 150ms + 500ms
- `fitAll()`: `paddingBottomRight` von 210 auf 80 reduziert (passt zur neuen Nav-Höhe)

## Ergebnis
- Karte füllt den gesamten Bereich oberhalb der Nav aus
- Bottom-Nav sitzt bündig am unteren Bildschirmrand
- Kein schwarzer Leerraum mehr
- Karussell, Panels und Toast positionieren sich relativ zu `--prx-nav-total`


## Service Worker Cache
- Cache-Key aktualisiert auf `pr-explorer-v3-4-9-geom1`, damit GitHub Pages/iOS Safari nicht die alte V3.4.0 ausliefert.
